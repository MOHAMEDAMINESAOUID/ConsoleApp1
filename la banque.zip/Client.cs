﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class Client {
        private string Nom, Prenom, Addresse;
        public Client(string N,string P,string A)
        {
            this.Nom = N;
            this.Prenom = P;
            this.Addresse = A;
        }
        public void Afficher()
        {
            Console.WriteLine("Nom : " + this.Nom);
            Console.WriteLine("Prenom : " + this.Prenom);
            Console.WriteLine("Addresse : " + this.Addresse);
        }

    }
}
