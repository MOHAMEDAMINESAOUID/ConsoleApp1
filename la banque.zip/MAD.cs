﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class MAD
    {
        private double Valeur;
        public MAD(double Val)
        {
            this.Valeur = Val;
        }
        public void Afficher()
        {
            Console.WriteLine(this.Valeur + "MAD");
        }
        public static MAD operator +(MAD v0, MAD v1)
        {
            MAD Somme = new MAD(0);
            Somme.Valeur = v0.Valeur + v1.Valeur;
            return Somme;

        }
        public static MAD operator -(MAD v0, MAD v1)
        {
            MAD SOUTRACTION = new MAD(0);
            SOUTRACTION.Valeur = v0.Valeur - v1.Valeur;
            return SOUTRACTION;

        }
        public static bool operator >(MAD v0, MAD v1)
        {
            if (v0.Valeur > v1.Valeur)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool operator <(MAD v0, MAD v1)
        {
            if (v0.Valeur < v1.Valeur)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool operator >=(MAD v0, MAD v1)
        {
            if (v0.Valeur >= v1.Valeur)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool operator <=(MAD v0, MAD v1)
        {
            if (v0.Valeur <= v1.Valeur)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool operator >(MAD v0, double v1)
        {
            if (v0.Valeur > v1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool operator <(MAD v0, double v1)
        {
            if (v0.Valeur > v1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
