﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Client client1 = new Client("SADAOUI", "MOHAMED", "Fes");
            Client client2 = new Client("ALAOUI", "FATIMA", "Berrchid");

            MAD MAD1 = new MAD(10000);
            MAD MAD2 = new MAD(2000);
            Compte compte1 = new Compte(client1, MAD1);
            Compte compte2 = new Compte(client2, MAD2);

            Console.WriteLine("*****  Client 1*****");
            client1.Afficher();
            Console.WriteLine("***** Client 2*****");
            client2.Afficher();
        
            Console.WriteLine("*****Consultation du compte 1 avant de débiter*****");
            compte1.Consulter();
            
            MAD deb = new MAD(2500);//plafond=4000 
            compte1.Debiter(deb);
            if (compte1.Debiter(deb))
            {
                Console.WriteLine("Compte 1 débiter avec succé!!");
            }
            else
                Console.WriteLine("Compte 1 n'est pas débiter!!");

         
            Console.WriteLine("*****Consultation du compte 1 après le débit*****");
            compte1.Consulter();
            
            MAD cred = new MAD(300);
            compte2.Crediter(cred);
            if (compte2.Crediter(cred))
            {
                Console.WriteLine("Compte 2 Créditer avec succé!!");
            }
            else
                Console.WriteLine("Compte 1 n'est pas créditer!!");

          
            Console.WriteLine("*****Consultation du compte 2 du client 2*****");
            compte2.Consulter();

          
            Console.WriteLine("*****Versement*****");
            MAD somme = new MAD(300);
            compte1.Verser(compte2, somme);
            if (compte1.Verser(compte2, somme))
            {
                Console.WriteLine("Virement bien passé !!");
            }
            else
                Console.WriteLine("Virement échoué !!");
           
            Console.WriteLine("*****Consultation du compte 1 *****");
            compte1.Consulter();

            Console.WriteLine("*****Consultation du compte 2 *****");
            compte2.Consulter();

        }
    }
}
